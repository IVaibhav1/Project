package org.springangular.cem.model;
import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.Data;
@Data
@Entity
public class Contact {
@Id
public String employeeid;
public String name;
public String email;
public String message;
public String getEmployeeid() {
	return employeeid;
}
public void setEmployeeid(String employeeid) {
	this.employeeid = employeeid;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public String getMessage() {
	return message;
}
public void setMessage(String message) {
	this.message = message;
}
public Contact(String employeeid, String name, String email, String message) {
	super();
	this.employeeid = employeeid;
	this.name = name;
	this.email = email;
	this.message = message;
}
public Contact() {
	super();
}


}
