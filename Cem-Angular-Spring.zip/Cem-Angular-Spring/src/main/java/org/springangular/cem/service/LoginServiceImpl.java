package org.springangular.cem.service;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springangular.cem.model.*;
import org.springangular.cem.repository.*;
import org.springangular.cem.service.*;
import org.springangular.cem.controller.*;

@Service
public class LoginServiceImpl implements IloginService{
	@Autowired
	private LoginRepo repo;
	@Override
	public Employee fetchList(String f,String p)
	{
		Employee obj= repo.fetchList(f,p);
		return obj;
		
		
	}
}
