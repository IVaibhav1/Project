package org.springangular.cem.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springangular.cem.model.*;

public interface CemRepositoryTimesheetReport
extends JpaRepository<TimesheetReport, Integer>{

}
