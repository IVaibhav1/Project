package org.springangular.cem.model;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.Data;
@Data
@Entity

public class TimesheetReport {
	@Id
	public String employeeid;
public String starttime;
public String exittime;

public String getStarttime() {
    return starttime;
}
public void setStarttime(String starttime) {
    this.starttime = starttime;
}
public String getExittime() {
    return exittime;
}
public void setExittime(String exittime) {
    this.exittime = exittime;
}
public String getEmployeeid() {
	return employeeid;
}
public void setEmployeeid(String employeeid) {
	this.employeeid = employeeid;
}
public TimesheetReport(String starttime, String exittime, String employeeid) {
	super();
	this.starttime = starttime;
	this.exittime = exittime;
	this.employeeid = employeeid;
}
public TimesheetReport() {
	super();
}
}