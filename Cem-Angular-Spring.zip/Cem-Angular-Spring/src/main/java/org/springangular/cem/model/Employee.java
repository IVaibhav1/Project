package org.springangular.cem.model;


import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.Data;
@Data
@Entity
public class Employee {
	@Id	
	public String employeeid;
	public String name;
	public String designation;
	public String phone;
	public String email;
	public String department;
	public String password;
	public String salary;
	public String project;
	public String supervisor;
	public String getEmployeeid() {
		return employeeid;
	}
	public void setEmployeeid(String employeeid) {
		this.employeeid = employeeid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getSalary() {
		return salary;
	}
	public void setSalary(String salary) {
		this.salary = salary;
	}
	public String getProject() {
		return project;
	}
	public void setProject(String project) {
		this.project = project;
	}
	public String getSupervisor() {
		return supervisor;
	}
	public void setSupervisor(String supervisor) {
		this.supervisor = supervisor;
	}
	public Employee(String employeeid, String name, String designation, String phone, String email, String department,
			String password, String salary, String project, String supervisor) {
		super();
		this.employeeid = employeeid;
		this.name = name;
		this.designation = designation;
		this.phone = phone;
		this.email = email;
		this.department = department;
		this.password = password;
		this.salary = salary;
		this.project = project;
		this.supervisor = supervisor;
	}
	public Employee() {
		super();
	}
	

}
