package org.springangular.cem.model;
import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.Data;
@Data
@Entity
public class LeaveReport {
	@Id
    public String employeeid;
    public String from_date;
    public String to_date;
    public String action;
    public String status;
    public String type;
    public String getEmployeeid() {
        return employeeid;
    }
    public void setEmployeeid(String employeeid) {
        this.employeeid = employeeid;
    }
    public String getFrom_date() {
        return from_date;
    }
    public void setFrom_date(String from_date) {
        this.from_date = from_date;
    }
    public String getTo_date() {
        return to_date;
    }
    public void setTo_date(String to_date) {
        this.to_date = to_date;
    }
    public String getAction() {
        return action;
    }
    public void setAction(String action) {
        this.action = action;
    }
    public String getStatus() {
        return status;
    }
    public void setStatus(String status) {
        this.status = status;
    }
    
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public LeaveReport(String employeeid, String from_date, String to_date, String action, String status,String type) {
		super();
		this.employeeid = employeeid;
		this.from_date = from_date;
		this.to_date = to_date;
		this.action = action;
		this.status = status;
		this.type=type;
	}
	public LeaveReport() {
		super();
	}
    
    
    
}
