package org.springangular.cem.repository;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.springangular.cem.controller.*;
import org.springangular.cem.model.*;
import org.springangular.cem.repository.*;
import org.springangular.cem.service.*;


@Repository
public interface LoginRepo extends JpaRepository<Employee,Integer> {
	@Transactional
	@Query(value="SELECT * FROM employee  where employeeid = ?1 and password = ?2  ",nativeQuery=true)
	public Employee fetchList(String employeeid,String password);
}