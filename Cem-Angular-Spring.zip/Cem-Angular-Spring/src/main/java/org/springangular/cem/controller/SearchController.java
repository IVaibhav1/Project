package org.springangular.cem.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import org.springangular.cem.controller.*;
import org.springangular.cem.model.*;
import org.springangular.cem.repository.*;
import org.springangular.cem.service.*;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class SearchController {
	@Autowired
	private IsearchService service;
	//private IsearchService service;
	
	@RequestMapping(path="/search/{employeeid}",method=RequestMethod.GET)
	public List<Employee> fetchProductList(@PathVariable String employeeid)
	{
		List<Employee> items=new ArrayList<Employee>();
		items=service.fetchList(employeeid);
		
		return items;
	}
}