package org.springangular.cem.service;
import java.util.List;

import org.springframework.stereotype.Service;

import org.springangular.cem.model.*;
import org.springangular.cem.repository.*;
import org.springangular.cem.service.*;
import org.springangular.cem.controller.*;
@Service
public interface IloginService {
 Employee fetchList(String f,String p);
}

