package org.springangular.cem.service;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import org.springangular.cem.model.*;
import org.springangular.cem.repository.*;

@Service
public class EmployeeService {
@Autowired
	public CemRepositoryEmployee employeerepo;
@Autowired
    public CemRepositoryContact  contactrepo;
@Autowired
    public CemRepositoryLeaveReport leavereportsrepo;
@Autowired
    public CemRepositoryTimesheetReport timesheetrepo;
    
    
	public List<Employee> getAllEmployees() {

		return employeerepo.findAll();
	}
	public Employee saveEmployee(Employee employee) {
       employee=employeerepo.save(employee);
		return employee;
	}
	public List<LeaveReport> getAllleaverequests() {

		return leavereportsrepo.findAll();
	}
	public List<TimesheetReport>getAllTimesheetReports()  {

		return timesheetrepo.findAll();
	}
	public LeaveReport saveLeaverequest(LeaveReport leaverequest) {
		leaverequest=leavereportsrepo.save(leaverequest);

		return leaverequest;
	}
	public TimesheetReport saveTimesheetReport(TimesheetReport timesheetReport) {
		timesheetReport=timesheetrepo.save(timesheetReport);

		return timesheetReport;
	}
	public Contact saveContact(Contact contact) {
		contact=contactrepo.save(contact);
		return contact;
	}
	public void saveLeavestatus(LeaveReport lr) {
		leavereportsrepo.save(lr);
	}
	public void deleteLeaveReport(LeaveReport lr) {

		leavereportsrepo.delete(lr);
	}
	public void deletetimesheetreport(TimesheetReport tr) {

		timesheetrepo.delete(tr);
	}
	public void deleteEmployee(Employee e) {

		employeerepo.delete(e);
	}
	
	/*
	 * public List<Employee> getAllCustomers() {
	 * 
	 * return EmpRepo.findAll(); }
	 */
	

}

