package org.springangular.cem.controller;


import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import org.springangular.cem.controller.*;
import org.springangular.cem.model.*;
import org.springangular.cem.repository.*;
import org.springangular.cem.service.*;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class LoginController {
	@Autowired
	private IloginService service;
	//private IsearchService service;
	
	@RequestMapping(path="/loginvalidate/{employeeid}/{password}",method=RequestMethod.POST)
	public String fetchProductList(@PathVariable String employeeid,@PathVariable String password)
	{
		
		
		String result;
		Employee obj=service.fetchList(employeeid, password);
		if(obj!=null)
			result="Success";
			else
			result="Unsuccessful";
			return result;
		
	}
}
