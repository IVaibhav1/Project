package org.springangular.cem.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import org.springangular.cem.service.*;



import org.springangular.cem.model.*;

@RestController
@RequestMapping("/Cem")
@CrossOrigin(origins = "http://localhost:4200")
public class CemController {
	@Autowired
	private EmployeeService employeeservice;
	
	
	  

	List<Employee>  listEmp ;
	List<Contact> contacts;
	List< LeaveReport> leavereports;
	List<TimesheetReport> timesheetreports;
	
	
	
	@GetMapping("/all/employees")
	public ResponseEntity<?> getAllEmployees() {
		ResponseEntity<?> response = null ;
		try {

			List<Employee> list = employeeservice.getAllEmployees();
			if(list!=null && !list.isEmpty()) {
				//list.sort((s1,s2)->s1.getName().compareTo(s2.getName()));
				
				response = new ResponseEntity<List<Employee>>(list, HttpStatus.OK);
			} else {
			response = new ResponseEntity<String>(
						"No Employee Found",
						HttpStatus.OK);
			}
		} catch (Exception e) {

			response =  new ResponseEntity<String>(
					"Unable to Fetch employees", 
					HttpStatus.INTERNAL_SERVER_ERROR); //500
			e.printStackTrace();
		}
		return response;
	}
	
	 @PostMapping("/addemployee")
	 public Employee saveEmployee(
	 		@RequestBody Employee employee)
	 {   Employee emp;
	 	try {
	 		
	 		 emp = employeeservice.saveEmployee(employee);
	        
	 	} catch (Exception e) {
	 		 emp =null;
	 		e.printStackTrace();
	 	}
	 	return emp;
	 }
	 @GetMapping("/getemployee/{id}")
		public Employee getOneEmployee(
				@PathVariable String id
				) 
		{
			Employee emp = null;
			listEmp =employeeservice.getAllEmployees();
			try {
				for(Employee employee:listEmp) {
					if(employee.getEmployeeid().equalsIgnoreCase(id)) {
						emp=employee;
					}
				}
				
			} catch (Exception e) {
				
				e.printStackTrace();
			}

			return emp;
		}
	 
	 
	 
	 
	 @GetMapping("/all/leaverequests")
		public ResponseEntity<?> getAllleaverequests() {
			ResponseEntity<?> response = null ;
			try {
				List<LeaveReport> list = employeeservice.getAllleaverequests();
				
				if(list!=null && !list.isEmpty()) {
					response = new ResponseEntity<List<LeaveReport>>(list, HttpStatus.OK);
				} else {
				response = new ResponseEntity<String>(
							"No Request Found",
							HttpStatus.OK);
				}
			} catch (Exception e) {

				response =  new ResponseEntity<String>(
						"Unable to fetch Requests", 
						HttpStatus.INTERNAL_SERVER_ERROR); //500
				e.printStackTrace();
			}
			return response;
		}
	 @PostMapping("/addleaverequest")
	 public LeaveReport saveLeaveRequest(
	 		@RequestBody LeaveReport leavereport)
	 {   LeaveReport ln;
	 	try {
	 		 ln = employeeservice.saveLeaverequest(leavereport);
//	 		 Loanstatus lns=new Loanstatus(loan.customerid,loan.status);
//	 		 CService.saveLoanStatus(lns);
	        
	 	} catch (Exception e) {
	 		 ln =null;
	 		e.printStackTrace();
	 	}
	 	return ln;
	 }
	 @PostMapping("/addtimesheetreport")
	 public TimesheetReport saveTimesheetReport(
	 		@RequestBody TimesheetReport timesheetreport)
	 {   TimesheetReport ts;
	 	try {
	 		 ts = employeeservice.saveTimesheetReport(timesheetreport);
//	 		 Loanstatus lns=new Loanstatus(loan.customerid,loan.status);
//	 		 CService.saveLoanStatus(lns);
	        
	 	} catch (Exception e) {
	 		 ts =null;
	 		e.printStackTrace();
	 	}
	 	return ts;
	 }
	 @PostMapping("/sendContact")
	 public Contact saveContact(
	 		@RequestBody Contact contact)
	 {   Contact ct;
	 	try {
	 		 ct = employeeservice.saveContact(contact);
//	 		 Loanstatus lns=new Loanstatus(loan.customerid,loan.status);
//	 		 CService.saveLoanStatus(lns);
	        
	 	} catch (Exception e) {
	 		 ct =null;
	 		e.printStackTrace();
	 	}
	 	return ct;
	 }
	 
	 @GetMapping("/all/gettimesheetreports")
		public ResponseEntity<?> getAlltimesheetreports() {
			ResponseEntity<?> response = null ;
			try {

				List<TimesheetReport>  list= employeeservice.getAllTimesheetReports();
				if(list!=null && !list.isEmpty()) {
					response = new ResponseEntity<List<TimesheetReport>>(list, HttpStatus.OK);
				} else {
				response = new ResponseEntity<String>(
							"No Request Found",
							HttpStatus.OK);
				}
			} catch (Exception e) {

				response =  new ResponseEntity<String>(
						"Unable to fetch Timesheet", 
						HttpStatus.INTERNAL_SERVER_ERROR); //500
				e.printStackTrace();
			}
			return response;
		}
	 
	 @PutMapping("/updatestatus1/{id}")
		public ResponseEntity<?> updateStatus1(
				@PathVariable String id,
				@RequestBody LeaveReport lr
				)
		{
		 ResponseEntity<?> resp =null; 
		 leavereports=employeeservice.getAllleaverequests();
		 String  status="Approved";
		try {    
	       for(LeaveReport lrs:leavereports) {
	    	   
	if(lrs.getEmployeeid().equalsIgnoreCase(id)) {
					
					lrs.setStatus(status);
					employeeservice.saveLeavestatus(lrs);

					System.out.println(lrs.getStatus());
					resp= new ResponseEntity<String>(status, HttpStatus.OK);
					
				}
	       }
	       
	       
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	 		
			

			return resp;
			
		}
	 @PutMapping("/updatestatus2/{id}")
		public ResponseEntity<?> updateStatus2(
				@PathVariable String id,
				@RequestBody LeaveReport lr
				)
		{
		 ResponseEntity<?> resp =null; 
		 leavereports=employeeservice.getAllleaverequests();
		 String  status="Rejected";
		try {    
	       for(LeaveReport lrs:leavereports) {
	    	   
	if(lrs.getEmployeeid().equalsIgnoreCase(id)) {
					
					lrs.setStatus(status);
					employeeservice.saveLeavestatus(lrs);

					System.out.println(lrs.getStatus());
					resp= new ResponseEntity<String>(status, HttpStatus.OK);
				}
	       }
	       
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	 		
			

			return resp;
		}
	 
	
	 
	 @DeleteMapping("/delete/{id}")
		public ResponseEntity<?> removeLoanRequest(
				@PathVariable String id
				)
		{
	       

			ResponseEntity<?> resp = null;
			listEmp =employeeservice.getAllEmployees();
			

			try {
				
				
				for(Employee e:listEmp) {
					if(e.getEmployeeid().equalsIgnoreCase(id)) {
						employeeservice.deleteEmployee(e);
						resp= new ResponseEntity<List<Employee>>(listEmp, HttpStatus.OK);
						break;
					}
				}
				
			} catch (Exception e) {
				resp=null;
				e.printStackTrace();
			}

			return resp;
		}
	 	 	

}
