import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HttpclientService, Employee, Contact } from '../httpclient.service';

@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.css']
})
export class ContactComponent implements OnInit {

contact:Contact=new Contact('','','','');
constructor(private httpClientService: HttpclientService,private router: Router) { }
  public showCapsWarning = false;



  ngOnInit(): void {
    this.contact= new Contact('', '', '', '');
  }
  createContact(): void {
    
    this.httpClientService.createContact(this.contact)
        .subscribe( data => {
          this.contact= new Contact('', '', '', '');

          alert('Your Details Sent, We Will Respond in your mentioned Email.');
          console.log('contact' + data);
        });
      }



  }
