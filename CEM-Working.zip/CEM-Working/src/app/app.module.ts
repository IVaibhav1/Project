import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule, Routes } from '@angular/router';
import { AppRoutingModule } from './app-routing.module';
import { HttpClientModule}  from '@angular/common/http';
import { AppComponent } from './app.component';
import { AboutComponent } from './about/about.component';
import { AdminloginComponent } from './adminlogin/adminlogin.component';
import { EmploginComponent } from './emplogin/emplogin.component';
import { ContactComponent } from './contact/contact.component';
import { IndexComponent } from './index/index.component';
import { AdminhomeComponent } from './adminhome/adminhome.component';
import { EmployeeprofileComponent } from './employeeprofile/employeeprofile.component';
import { ViewemployeesComponent } from './viewemployees/viewemployees.component';
import { LeaverequestsComponent } from './leaverequests/leaverequests.component';
import { EmpdailyreportsComponent } from './empdailyreports/empdailyreports.component';
import { ApplyforleaveComponent } from './applyforleave/applyforleave.component';
import { FilltimesheetComponent } from './filltimesheet/filltimesheet.component';
import { LeavebanceComponent } from './leavebance/leavebance.component';
import { AddemployeeComponent } from './addemployee/addemployee.component';
import { FormsModule } from '@angular/forms';
import { ElogoutComponent } from './elogout/elogout.component';
import { AlogoutComponent } from './alogout/alogout.component';


const appRoutes: Routes = [
  { path: '', component: IndexComponent },
  { path: 'About', component: AboutComponent  },
  { path: 'AdminLogin', component: AdminloginComponent },
  { path: 'EmployeeLogin', component: EmploginComponent },
  { path: 'Contact', component: ContactComponent},
  { path: 'LeaveRequests',component:LeaverequestsComponent},
  { path: 'LeaveBalance',component:LeavebanceComponent},
  { path: 'FillTimesheet',component:FilltimesheetComponent},
  { path: 'ApplyForLeave',component:ApplyforleaveComponent},
  { path: 'ViewEmployees',component:ViewemployeesComponent},
  { path: 'EmployeeProfile',component:EmployeeprofileComponent},
  { path: 'EmployeeDailyReports',component:EmpdailyreportsComponent},
  { path: 'AdminHome',component:AdminhomeComponent},
  {path :'AddEmployee',component:AddemployeeComponent},
  {path:'Elogout',component:ElogoutComponent},
  {path:'Alogout',component:AlogoutComponent}

  ];

@NgModule({
  declarations: [
    AppComponent,
    AboutComponent,
    AdminloginComponent,
    EmploginComponent,
    ContactComponent,
    IndexComponent,
    AdminhomeComponent,
    EmployeeprofileComponent,
    ViewemployeesComponent,
    LeaverequestsComponent,
    EmpdailyreportsComponent,
    ApplyforleaveComponent,
    FilltimesheetComponent,
    LeavebanceComponent,
    AddemployeeComponent,
    ElogoutComponent,
    AlogoutComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    RouterModule.forRoot(appRoutes)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
