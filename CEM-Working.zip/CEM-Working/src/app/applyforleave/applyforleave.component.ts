import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HttpclientService, Employee ,LeaveReport,LeaveRequestStatus} from '../httpclient.service';


@Component({
  selector: 'app-applyforleave',
  templateUrl: './applyforleave.component.html',
  styleUrls: ['./applyforleave.component.css']
})
export class ApplyforleaveComponent implements OnInit {
 
  leavereport: LeaveReport = new LeaveReport('','','','','','');
  

  constructor(private httpClientService: HttpclientService,private router: Router) { }
  public showCapsWarning = false;

  ngOnInit(): void {
    this.leavereport= new LeaveReport('','','','','','');

  }
  createLeaveReport(): void {
  this.leavereport.status='Requested';
    this.httpClientService.createAddLeaveRequest(this.leavereport)
        .subscribe( data => {
          this.leavereport= new LeaveReport('','','','','','');

          alert('The Leave Request has been sent to the Admin');
          console.log('leavereport' + data);
          //this.router.navigate(['EmployeeProfile']);
        });
      }
}



