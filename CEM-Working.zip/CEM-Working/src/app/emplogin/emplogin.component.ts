import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HttpclientService, Employee } from '../httpclient.service';

@Component({
  selector: 'app-emplogin',
  templateUrl: './emplogin.component.html',
  styleUrls: ['./emplogin.component.css']
})
export class EmploginComponent implements OnInit{

  public employeeid: string = '';
  public password: string = '';
  res:string='';
    constructor(private httpClientService: HttpclientService, private router: Router) { }
  
    ngOnInit(): void {
    }

    public loginvalidat(employeeid:string,password:string) {
      let response=this.httpClientService.loginvalidate(employeeid,password);
      response.subscribe(data=>
        {  
          this.res= data;
          console.log(this.res);
          this.employeeid=employeeid;
          
        if(this.res=="Success"){
          sessionStorage.setItem("employeeid",this.employeeid);
            this.router.navigate(['EmployeeProfile']);
            
           }
           else{
            //this.router.navigate(['auth/login']);
            alert("Invalid username and password");
           }
         
      },
      error => {
        console.log(error);
      });
    }
    
}
