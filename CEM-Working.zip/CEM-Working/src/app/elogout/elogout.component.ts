import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-elogout',
  templateUrl: './elogout.component.html',
  styleUrls: ['./elogout.component.css']
})
export class ElogoutComponent implements OnInit {

  constructor(private router: Router) { }

  ngOnInit(): void {
    this.logout();

  }
  logout()
  {
    sessionStorage.removeItem("employeeid");
    this.router.navigate(['']);
    
    
    }

}
