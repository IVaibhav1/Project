import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { $ } from 'protractor';
export class Employee{
  constructor(
    public employeeid: string,
    public name: string,
    public designation: string,
    public phone: String,
    public email: string,
    public department: string,
    public password:string,
    public salary:string,
    public project:string,
    public supervisor:string
  ) {}
}

export class Contact{
  constructor(
    public employeeid: string,
    public name: string,
    public email: string,
    public message:string
  ) {}
}
export class LeaveReport{//admin side leave requests to take action
  constructor(
    public employeeid:string,
    public from_date: string,
    public to_date: string,
    public action:string,
    public status:string,
    public type:string

  ){}
}
export class LeaveRequestStatus{//emp side table for viewing its leave request status
  constructor(
  public from_date:string,
  public to_date:string,
  public status:string
  )
  {}
  }

  

export class TimesheetReport{// admin side report to view but table to be filled by emp side and saved in db, that is to be viewed by admin
  constructor(
    public employeeid:string,
    public starttime:string,
    public exittime:string
  )

  {}
}




@Injectable({
  providedIn: 'root'
})

export class HttpclientService {

  constructor(
    private httpClient: HttpClient
  ) {
     }

     getAllEmployees()
  {
    //console.log('test call');
    return this.httpClient.get<Employee[]>('http://localhost:9040/Cem' + '/' + 'all' + '/' + 'employees');
  }

  
  public deleteOneEmployee(employee: Employee) {
    return this.httpClient.delete<Employee>('http://localhost:9040/Cem' + '/' + employee.employeeid);
  }
  

  public createEmployee(employee: any) {
    return this.httpClient.post<Employee>('http://localhost:9040/Cem' + '/' + 'addemployee', employee);
  }

  // getOneEmployee(employeeid: String): Observable<Employee> {
  //   return this.httpClient.get<Employee>('http://localhost:9040/Cem' + '/' + 'getemployee' + '/' + employeeid);
  // }
  // public getOneEmployee(employeeid:any): Observable<any> {
  //   return this.httpClient.get<any>('http://localhost:9040/Cem' + '/'+'getoneemployee', employeeid);
  // }
  public getOneEmployee(employeeid:any): Observable<any> {
    return this.httpClient.get<any>("http://localhost:9040/search/" + "/"+ employeeid);
  } 

  public loginvalidate(employeeid:any,password:any)
  {
    return this.httpClient.post("http://localhost:9040/loginvalidate"+ "/"+ employeeid + "/" + password ,{employeeid,password},{responseType:"text"})
  }

public createContact(contact: any) {
  return this.httpClient.post<Contact>('http://localhost:9040/Cem' + '/' + 'sendContact', contact);
}
public createAddLeaveRequest(leavereport:LeaveReport) {
  return this.httpClient.post<LeaveReport>('http://localhost:9040/Cem' + '/' + 'addleaverequest', leavereport);
}
public createTimesheetReport(timesheetreport:any) {
  return this.httpClient.post<TimesheetReport>('http://localhost:9040/Cem' + '/' + 'addtimesheetreport', timesheetreport);
}

getAllLeaveRequests()
{
  return this.httpClient.get<LeaveReport[]>('http://localhost:9040/Cem' + '/' + 'all' + '/' + 'leaverequests');
}
getTimesheetReport()
{
  return this.httpClient.get<TimesheetReport[]>('http://localhost:9040/Cem' + '/' + 'all' + '/' + 'gettimesheetreports');
}


//unused part
// tslint:disable-next-line:ban-types
public rejectleaverequest(employeeid: String) {
  return this.httpClient.delete('http://localhost:9040/Cem' + '/' + 'rejectleaverequest' + '/' + employeeid);
}

UpdateLeaveStatus1(employeeid: String,leavereport:LeaveReport){
  return this.httpClient.put<LeaveReport>('http://localhost:9040/Cem' + '/' + 'updatestatus1' + '/' + employeeid,leavereport);
}
UpdateLeaveStatus2(employeeid: String,leavereport:LeaveReport){
  return this.httpClient.put<LeaveReport>('http://localhost:9040/Cem' + '/' + 'updatestatus2' + '/' + employeeid,leavereport);
}
//unused part
getMyLeaveRequests()
{
  return this.httpClient.get<LeaveReport[]>('http://localhost:9040/Cem' + '/' + 'all' + '/' + 'myleaverequests');
}


// tslint:disable-next-line:ban-types
getLeaveStatus(employeeid: String): Observable<LeaveReport> {
  return this.httpClient.get<LeaveReport>('http://localhost:9040/Cem' + '/' + 'getleavestatus' + '/' + employeeid);
}
}

