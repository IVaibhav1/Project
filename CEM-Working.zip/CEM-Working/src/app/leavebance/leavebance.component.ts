import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpclientService, LeaveReport } from '../httpclient.service';

@Component({
  selector: 'app-leavebance',
  templateUrl: './leavebance.component.html',
  styleUrls: ['./leavebance.component.css']
})
export class LeavebanceComponent implements OnInit {
  leavereport:LeaveReport[] | undefined;
  employeeid:any;
  employee:any;
  status:any;
  leavestatus:any;
  type:any;

  constructor(private httpClientService: HttpclientService, private router: Router, private activatedRoute: ActivatedRoute) { }

  ngOnInit(): void {
    this.employeeid = this.activatedRoute.snapshot.params.employeeid;
    this.httpClientService.getOneEmployee(this.employeeid).subscribe(
      data => {
      this.employee = data;
       }, error => {
      console.log(error);
    });

    // this.httpClientService.getLeaveStatus(this.employeeid).subscribe(
    //   data => {
    //     this.status = data;
    //      }, error => {
    //     console.log(error);
    //   });
      this.getMyLeaveRequest();

  }
  getMyLeaveRequest() {
    return this.httpClientService.getAllLeaveRequests().subscribe(
      data => {
        this.leavereport = data;
      }, error => {
        console.log(error);
      }
    );
  }
}
