import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AboutComponent } from './about/about.component';
import { AdminloginComponent } from './adminlogin/adminlogin.component';
import { EmploginComponent } from './emplogin/emplogin.component';
import { ContactComponent } from './contact/contact.component';
import { IndexComponent } from './index/index.component';
import { AdminhomeComponent } from './adminhome/adminhome.component';
import { EmployeeprofileComponent } from './employeeprofile/employeeprofile.component';
import { ViewemployeesComponent } from './viewemployees/viewemployees.component';
import { LeaverequestsComponent } from './leaverequests/leaverequests.component';
import { EmpdailyreportsComponent } from './empdailyreports/empdailyreports.component';
import { ApplyforleaveComponent } from './applyforleave/applyforleave.component';
import { FilltimesheetComponent } from './filltimesheet/filltimesheet.component';
import { LeavebanceComponent } from './leavebance/leavebance.component';
import { AddemployeeComponent } from './addemployee/addemployee.component';
import{ElogoutComponent}from './elogout/elogout.component';
import{AlogoutComponent}from './alogout/alogout.component';




const routes: Routes = [ { path: '', component: IndexComponent },
{ path: 'About', component: AboutComponent  },
{ path: 'AdminLogin', component: AdminloginComponent },
{ path: 'EmployeeLogin', component: EmploginComponent },
{ path: 'Contact', component: ContactComponent},
{ path: 'LeaveRequests',component:LeaverequestsComponent},
{ path: 'LeaveBalance',component:LeavebanceComponent},
{ path: 'FillTimesheet',component:FilltimesheetComponent},
{ path: 'ApplyForLeave',component:ApplyforleaveComponent},
{ path: 'ViewEmployees',component:ViewemployeesComponent},
{ path: 'EmployeeProfile',component:EmployeeprofileComponent},
{ path: 'EmployeeDailyReports',component:EmpdailyreportsComponent},
{ path: 'AdminHome',component:AdminhomeComponent},
{path :'AddEmployee',component:AddemployeeComponent},
{path:'Elogout',component:ElogoutComponent},
{path:'Alogout',component:AlogoutComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
