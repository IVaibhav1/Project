import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthenticationService } from '../service/authentication.service';

@Component({
  selector: 'app-adminlogin',
  templateUrl: './adminlogin.component.html',
  styleUrls: ['./adminlogin.component.css']
})
export class AdminloginComponent implements OnInit {

  adminid = 'admin'
  password = ''
  invalidLogin = false

  constructor(private router: Router, private loginservice: AuthenticationService) { }

  ngOnInit():void {
  }

  loginAdmin() {
    if (this.loginservice.authenticate(this.adminid, this.password)
    ) {
      this.router.navigate(['AdminHome'])
      this.invalidLogin = false
    } 
    else{
      this.invalidLogin = true
      alert("Invalid Credentials")
    }
  }

}