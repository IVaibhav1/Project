import { Time } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import {  ActivatedRoute, Router }from '@angular/router';
import {HttpclientService,LeaveReport,TimesheetReport} from '../httpclient.service';

@Component({
  selector: 'app-empdailyreports',
  templateUrl: './empdailyreports.component.html',
  styleUrls: ['./empdailyreports.component.css']
})
export class EmpdailyreportsComponent implements OnInit {
  
  timesheetreport:TimesheetReport[] | undefined;

  constructor(private httpClientService: HttpclientService, private router: Router, private activatedRoute: ActivatedRoute) { }
  ngOnInit(): void {
   
    this.getTimesheetReport();
  }
  getTimesheetReport() {
    return this.httpClientService.getTimesheetReport()
    .subscribe(
      data => {
        this.timesheetreport = data;
      }, error => {
        console.log(error);
      }
    );
  }

  

}
