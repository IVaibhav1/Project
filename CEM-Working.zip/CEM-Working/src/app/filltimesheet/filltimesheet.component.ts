import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HttpclientService, Employee ,LeaveReport,LeaveRequestStatus,TimesheetReport} from '../httpclient.service';

@Component({
  selector: 'app-filltimesheet',
  templateUrl: './filltimesheet.component.html',
  styleUrls: ['./filltimesheet.component.css']
})
export class FilltimesheetComponent implements OnInit {
  
  timesheetreport:TimesheetReport=new TimesheetReport('','','');
  

  constructor(private httpClientService: HttpclientService,private router: Router) { }
  public showCapsWarning = false;

  ngOnInit(): void {
    this.timesheetreport= new TimesheetReport('', '', '');
    

  }
  public createTimesheetReport(): void { 
  
    this.httpClientService.createTimesheetReport(this.timesheetreport)
        .subscribe( data => {
          this.timesheetreport= new TimesheetReport('', '', '');

          alert('You Have Successfully Filled Timesheet');
          console.log('leavereport' + data);
          //this.router.navigate(['EmployeeProfile']);
        });
      }

}
