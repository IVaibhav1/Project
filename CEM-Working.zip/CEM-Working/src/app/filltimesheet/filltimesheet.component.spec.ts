import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FilltimesheetComponent } from './filltimesheet.component';

describe('FilltimesheetComponent', () => {
  let component: FilltimesheetComponent;
  let fixture: ComponentFixture<FilltimesheetComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FilltimesheetComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(FilltimesheetComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
