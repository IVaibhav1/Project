import { Component, OnInit } from '@angular/core';
import { HttpclientService, Employee ,LeaveReport,LeaveRequestStatus} from '../httpclient.service';
import { ActivatedRoute, Router } from '@angular/router';


@Component({
  selector: 'app-employeeprofile',
  templateUrl: './employeeprofile.component.html',
  styleUrls: ['./employeeprofile.component.css']
})
export class EmployeeprofileComponent implements OnInit {
  employeeid:any;
  employee: any;
  httpClientService: any;
  SessionValue : any;

  constructor(private service: HttpclientService, private router: Router,private activatedRoute: ActivatedRoute) { }

  // on page load call this method
  ngOnInit(): void {
    
    this.getEmployee();
   
}

  getEmployee() {
    this.SessionValue = sessionStorage.getItem("employeeid");
    return this.service.getOneEmployee(this.SessionValue)
    .subscribe(
      data => {
        this.employee = data;
      }, error => {
        console.log(error);
      }
    );
  }

}
