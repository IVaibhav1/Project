import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EmpdailyreportsComponent } from './empdailyreports.component';

describe('EmpdailyreportsComponent', () => {
  let component: EmpdailyreportsComponent;
  let fixture: ComponentFixture<EmpdailyreportsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EmpdailyreportsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EmpdailyreportsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
