import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HttpclientService, Employee ,LeaveReport,LeaveRequestStatus} from '../httpclient.service';

@Component({
  selector: 'app-viewemployees',
  templateUrl: './viewemployees.component.html',
  styleUrls: ['./viewemployees.component.css']
})
export class ViewemployeesComponent implements OnInit {

  employees: Employee[] | undefined;
  message: any;
  // inject service layer
  constructor(private service: HttpclientService, private router: Router) { }

  // on page load call this method
  ngOnInit(): void {
    this.getAllEmployees();
  }
  getAllEmployees() {
    return this.service.getAllEmployees()
    .subscribe(
      data => {
        this.employees = data;
      }, error => {
        console.log(error);
      }
    );
  }
  deleteOneEmployee(employee: Employee) {
    if (confirm('Do you want to remove this employee?')) {
      this.service.deleteOneEmployee(employee).subscribe(data => {
        this.message = data;
        this.getAllEmployees();
      }, error => {
        console.log(error);
      });
    } 
    else {
      this.message = '';
    }

  }

}
