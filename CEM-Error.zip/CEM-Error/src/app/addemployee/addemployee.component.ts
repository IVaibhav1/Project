import { Component, OnInit } from '@angular/core';
import { HttpclientService, Employee } from '../httpclient.service';
import { Router } from '@angular/router';

 

@Component({
  selector: 'app-addemployee',
  templateUrl: './addemployee.component.html',
  styleUrls: ['./addemployee.component.css']
})
export class AddemployeeComponent implements OnInit {
  employee: Employee = new Employee('', '', '', '', '', '', '','','','');


  constructor(private httpClientService: HttpclientService,private router: Router) { }
  public showCapsWarning = false;



  ngOnInit(): void {
    this.employee= new Employee('', '', '', '', '', '', '','','','');
    //this.createEmployee();
  }
  createEmployee(): void {
    this.employee.employeeid = 'EMP101' + this.employee.phone;
    this.employee.password='CEM'+this.employee.email;

    
    this.httpClientService.createEmployee(this.employee)
        .subscribe( data => {
          this.employee= new Employee('', '', '', '', '', '', '','','','');

          alert('EMployee Account Created'+'employee Id =' + data.employeeid + ' and Password='+data.password);
          console.log('employee' + data);
          this.router.navigate(['AdminHome']);

        });
      }

       //showCapsWarning = false;

        public VerifyPassword(e: { keyCode: number; }){
          if(e.keyCode>=65 && e.keyCode<=90) 
      {
              this.showCapsWarning = true;
          } else {
            this.showCapsWarning = false;
          }
      }
      public regExp1=/^[a-zA-Z0-9.!#$%&’*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;

}
