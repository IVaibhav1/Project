import { Component, OnInit } from '@angular/core';
import {  ActivatedRoute, Router }from '@angular/router';
import {HttpclientService,LeaveReport} from '../httpclient.service';

@Component({
  selector: 'app-leaverequests',
  templateUrl: './leaverequests.component.html',
  styleUrls: ['./leaverequests.component.css']
})
export class LeaverequestsComponent implements OnInit {
  
leavereport: LeaveReport[] | undefined ;
  message:any;
  constructor(private httpClientService: HttpclientService, private router: Router, private activatedRoute: ActivatedRoute) { }

  ngOnInit(): void {
    this.getAllLeaveRequests();
  }
  getAllLeaveRequests() {
    return this.httpClientService.getAllLeaveRequests()
    .subscribe(
      data => {
        this.leavereport = data;
      }, error => {
        console.log(error);
      }
    );
  }

  rejectleaverequest(employeeid: String,leavereport:LeaveReport){
    if (confirm('Do you Really Want To Reject Leave Request')) {
      this.httpClientService.UpdateLeaveStatus1(employeeid,leavereport).subscribe(
        data => {
                   //this.leavereport[]=data;
      }, error => {
        console.log(error);
      });
    }
    this.httpClientService.getAllLeaveRequests().subscribe(
      data => {
        
        //alert('inside');

        this.leavereport = data;
      }, error => {
        console.log(error);
      }
    );

  }
  approveleaverequest(employeeid: string,leavereport:LeaveReport){
    this.httpClientService.UpdateLeaveStatus2(employeeid,leavereport).subscribe(
      data => {
        //this.status=data;

         }, error => {
        console.log(error);
      });
    
    
      }
 
}
